// ================================
// MENU MOBILE - BTP & ENR SARL
// ================================

const menuToggle = document.querySelector(".menu-toggle");
const navMenu = document.querySelector(".nav-menu");

// Ouvrir / fermer le menu
menuToggle.addEventListener("click", () => {
    navMenu.classList.toggle("active");

    // Changer l'icône ☰ / ✕
    if (navMenu.classList.contains("active")) {
        menuToggle.textContent = "✕";
        menuToggle.setAttribute("aria-label", "Fermer le menu");
    } else {
        menuToggle.textContent = "☰";
        menuToggle.setAttribute("aria-label", "Ouvrir le menu");
    }
});

// Fermer automatiquement le menu après avoir cliqué sur un lien
const navLinks = document.querySelectorAll(".nav-menu a");

navLinks.forEach(link => {
    link.addEventListener("click", () => {
        navMenu.classList.remove("active");
        menuToggle.textContent = "☰";
        menuToggle.setAttribute("aria-label", "Ouvrir le menu");
    });
});